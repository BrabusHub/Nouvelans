# Toi, moi & l'Europe ♡

Site statique pour le road trip **30 décembre 2026 → 5 janvier 2027**.

## Mettre en ligne sur GitHub Pages

1. Créer un dépôt public sur https://github.com/new (ex. `notre-roadtrip`).
2. Ajouter le fichier `index.html` à la racine du dépôt (pas dans un sous-dossier).
3. Dans **Settings → Pages**, choisir **Deploy from a branch** puis `main` et `/(root)`. Enregistrer.
4. Ouvrir l'adresse affichée par GitHub Pages, généralement `https://UTILISATEUR.github.io/notre-roadtrip/`.

## Modifier les Airbnb

Sur le site, cliquer sur « Ajouter un Airbnb » sous une journée : nom, lien, dates, adresse, note. Rien de financier n'est affiché ni demandé.

**Important :** GitHub Pages est un hébergement statique. Les Airbnb saisis sont enregistrés **uniquement dans le navigateur utilisé**, et non dans GitHub. Pour transférer les données d'un appareil à l'autre, utiliser **Exporter nos logements** et **Importer des logements**. Une modification dans le navigateur ne change pas le fichier `index.html` sur GitHub ni les données vues par quelqu'un d'autre.

Pour publier les Airbnb directement dans une version commune du site, il faudra modifier le code ou ajouter une base de données / un service de synchronisation.

## Détails

- 6 nuits : Stuttgart (30), Vienne (31), Budapest (01), Berlin (02 et 03), Amsterdam (04).
- Les distances/horaires sont **estimés**, ne sont pas des horaires garantis et n'intègrent pas les aléas hivernaux.
- Les activités restent des suggestions ; vérifier les horaires et réserver si besoin.
- Le musée Mercedes-Benz est annoncé ouvert le 30 décembre 2026, mais l'arrivée vers 14 h après une longue route reste incertaine.
- Carte Leaflet / OpenStreetMap : nécessite Internet pour s'afficher.
- Aucune donnée personnelle ni clé API n'est nécessaire.

## Liste Airbnb partagée

La page contient un bouton vers la liste Airbnb partagée. Il ne récupère pas automatiquement les annonces : compléter ensuite les emplacements correspondant aux six nuits.


## Photo de couverture

Le fichier `notre-photo.jpg` est utilisé comme fond de la page d’accueil. Il doit rester **à côté de `index.html`** dans le dépôt GitHub pour que la photo s’affiche.
